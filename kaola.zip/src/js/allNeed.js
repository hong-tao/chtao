require(['jquery','login'],function(){

   
});


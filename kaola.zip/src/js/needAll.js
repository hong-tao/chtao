require(['config'],function(){

    require(['allNeed','buycar','common','detail','goods','regist','iindex']){

        var res = $('.userLogin');
        console.log(res);
        








    });
});


